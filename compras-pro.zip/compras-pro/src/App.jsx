import { useState, useRef, useEffect } from "react";

// ─── THEME ────────────────────────────────────────────────────────────────────
const C = {
  bg: "#0d1117",
  card: "#161b25",
  border: "#21293a",
  accent: "#f0a500",
  accentDim: "#f0a50020",
  accentLight: "#f0a50040",
  text: "#dde3f0",
  muted: "#6b7592",
  success: "#27c87a",
  danger: "#e84c6a",
};

// ─── DEFAULT DATA ─────────────────────────────────────────────────────────────
const DEFAULT_SUPPLIERS = [
  { id: 1, name: "Distribuidora El Sol", category: "Lácteos y Fiambres", phone: "5491122334455" },
  { id: 2, name: "Verduras del Campo", category: "Frutas y Verduras", phone: "5491133445566" },
  { id: 3, name: "Bebidas Norteña", category: "Bebidas", phone: "5491144556677" },
  { id: 4, name: "Frigorífico Central", category: "Carnes", phone: "5491155667788" },
];

const DEFAULT_PRODUCTS = [
  { id: 1, name: "Harina 000", unit: "kg", supplierId: 1, stock: 5, minStock: 20 },
  { id: 2, name: "Harina 0000", unit: "kg", supplierId: 1, stock: 12, minStock: 15 },
  { id: 3, name: "Azúcar", unit: "kg", supplierId: 1, stock: 8, minStock: 10 },
  { id: 4, name: "Aceite girasol", unit: "lt", supplierId: 1, stock: 4, minStock: 12 },
  { id: 5, name: "Tomate perita", unit: "kg", supplierId: 2, stock: 3, minStock: 15 },
  { id: 6, name: "Cebolla", unit: "kg", supplierId: 2, stock: 6, minStock: 10 },
  { id: 7, name: "Papa", unit: "kg", supplierId: 2, stock: 20, minStock: 25 },
  { id: 8, name: "Lechuga", unit: "unid", supplierId: 2, stock: 5, minStock: 20 },
  { id: 9, name: "Coca-Cola 2.25lt", unit: "unid", supplierId: 3, stock: 10, minStock: 24 },
  { id: 10, name: "Agua mineral 500ml", unit: "unid", supplierId: 3, stock: 8, minStock: 30 },
  { id: 11, name: "Cerveza lata", unit: "unid", supplierId: 3, stock: 24, minStock: 48 },
  { id: 12, name: "Asado", unit: "kg", supplierId: 4, stock: 4, minStock: 10 },
  { id: 13, name: "Pollo entero", unit: "kg", supplierId: 4, stock: 6, minStock: 15 },
  { id: 14, name: "Milanesa de ternera", unit: "kg", supplierId: 4, stock: 3, minStock: 12 },
];

const DEFAULT_HISTORY = [
  { id: "OC-001", date: "2026-05-10", supplierId: 1, supplierName: "Distribuidora El Sol", items: [{ name: "Harina 000", qty: 25, unit: "kg" }, { name: "Azúcar", qty: 10, unit: "kg" }], status: "entregada" },
  { id: "OC-002", date: "2026-05-08", supplierId: 4, supplierName: "Frigorífico Central", items: [{ name: "Asado", qty: 15, unit: "kg" }, { name: "Pollo entero", qty: 20, unit: "kg" }], status: "entregada" },
  { id: "OC-003", date: "2026-05-12", supplierId: 2, supplierName: "Verduras del Campo", items: [{ name: "Tomate perita", qty: 20, unit: "kg" }, { name: "Lechuga", qty: 15, unit: "unid" }], status: "pendiente" },
];

// ─── STORAGE (localStorage para PWA) ─────────────────────────────────────────
const load = (key, fallback) => {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch { return fallback; }
};
const save = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
};

// ─── TABS ─────────────────────────────────────────────────────────────────────
const TABS = [
  { id: "nueva", label: "Nueva OC", icon: "📋" },
  { id: "stock", label: "Stock", icon: "📦" },
  { id: "historial", label: "Historial", icon: "🕐" },
  { id: "config", label: "Config", icon: "⚙️" },
  { id: "ia", label: "IA", icon: "🤖" },
];

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState("nueva");
  const [suppliers, setSuppliers] = useState(() => load("cp_suppliers", DEFAULT_SUPPLIERS));
  const [products, setProducts] = useState(() => load("cp_products", DEFAULT_PRODUCTS));
  const [history, setHistory] = useState(() => load("cp_history", DEFAULT_HISTORY));

  const updateSuppliers = (v) => { setSuppliers(v); save("cp_suppliers", v); };
  const updateProducts = (v) => { setProducts(v); save("cp_products", v); };
  const updateHistory = (v) => { setHistory(v); save("cp_history", v); };

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "'DM Sans', sans-serif", color: C.text, maxWidth: 480, margin: "0 auto", paddingBottom: 80 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        body{background:#0d1117}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-track{background:${C.bg}}
        ::-webkit-scrollbar-thumb{background:${C.border};border-radius:4px}
        input,textarea,select{background:${C.card};color:${C.text};border:1.5px solid ${C.border};border-radius:10px;padding:10px 14px;font-family:'DM Sans',sans-serif;font-size:14px;width:100%;outline:none;transition:border .15s}
        input:focus,textarea:focus,select:focus{border-color:${C.accent}}
        button{cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .15s}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        .fu{animation:fadeUp .2s ease forwards}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
      `}</style>

      {/* Header */}
      <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: "16px 20px 12px", position: "sticky", top: 0, zIndex: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, background: C.accent, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🛒</div>
          <div>
            <div style={{ fontFamily: "'Space Mono',monospace", fontWeight: 700, fontSize: 15, color: C.accent, letterSpacing: 1.5 }}>COMPRAS PRO</div>
            <div style={{ fontSize: 10, color: C.muted, letterSpacing: .5 }}>GESTIÓN DE MATERIA PRIMA</div>
          </div>
        </div>
      </div>

      {/* Page */}
      <div style={{ padding: "16px 14px 0" }}>
        {tab === "nueva"     && <TabNuevaOC suppliers={suppliers} products={products} history={history} onSaveHistory={updateHistory} onUpdateStock={updateProducts} />}
        {tab === "stock"     && <TabStock suppliers={suppliers} products={products} onUpdate={updateProducts} />}
        {tab === "historial" && <TabHistorial history={history} suppliers={suppliers} onUpdate={updateHistory} />}
        {tab === "config"    && <TabConfig suppliers={suppliers} products={products} onUpdateSuppliers={updateSuppliers} onUpdateProducts={updateProducts} />}
        {tab === "ia"        && <TabIA suppliers={suppliers} products={products} />}
      </div>

      {/* Bottom nav */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: C.card, borderTop: `1px solid ${C.border}`, display: "flex", zIndex: 30 }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, padding: "9px 2px 11px", background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
            <span style={{ fontSize: 19 }}>{t.icon}</span>
            <span style={{ fontSize: 9, fontWeight: 700, color: tab === t.id ? C.accent : C.muted, letterSpacing: .5 }}>{t.label}</span>
            {tab === t.id && <div style={{ width: 18, height: 2, background: C.accent, borderRadius: 2 }} />}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── NUEVA OC ─────────────────────────────────────────────────────────────────
function TabNuevaOC({ suppliers, products, history, onSaveHistory, onUpdateStock }) {
  const [supplierId, setSupplierId] = useState("");
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [manualName, setManualName] = useState("");
  const [manualUnit, setManualUnit] = useState("kg");
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);

  const supplier = suppliers.find(s => s.id === Number(supplierId));
  const catalog = products.filter(p =>
    (!supplierId || p.supplierId === Number(supplierId)) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggle = (p) => setItems(prev => prev.find(i => i.id === p.id) ? prev.filter(i => i.id !== p.id) : [...prev, { ...p, qty: 1 }]);
  const setQty = (id, v) => setItems(prev => prev.map(i => i.id === id ? { ...i, qty: Math.max(1, Number(v) || 1) } : i));
  const addManual = () => {
    if (!manualName.trim()) return;
    setItems(prev => [...prev, { id: `m${Date.now()}`, name: manualName.trim(), unit: manualUnit, qty: 1, manual: true }]);
    setManualName("");
  };

  const handleSend = () => {
    if (!supplier || !items.length) return;
    const lines = [`*Orden de Compra — ${new Date().toLocaleDateString("es-AR")}*`, `Proveedor: ${supplier.name}`, "─────────────────", ...items.map(i => `• ${i.name}: *${i.qty} ${i.unit}*`)];
    if (note) lines.push(`\n📝 ${note}`);
    window.open(`https://wa.me/${supplier.phone}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
    const newOC = {
      id: `OC-${String(history.length + 1).padStart(3, "0")}`,
      date: new Date().toISOString().split("T")[0],
      supplierId: supplier.id,
      supplierName: supplier.name,
      items: items.map(i => ({ name: i.name, qty: i.qty, unit: i.unit })),
      status: "pendiente",
    };
    onSaveHistory([newOC, ...history]);
    setSent(true);
    setTimeout(() => { setSent(false); setItems([]); setNote(""); setSupplierId(""); }, 2500);
  };

  return (
    <div className="fu">
      <Label icon="🏪" text="Proveedor" />
      <select value={supplierId} onChange={e => { setSupplierId(e.target.value); setItems([]); }} style={{ marginBottom: 16 }}>
        <option value="">Seleccioná un proveedor…</option>
        {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
      </select>

      {supplierId && <>
        <Label icon="🔍" text="Catálogo" />
        <input placeholder="Buscar insumo…" value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 8 }} />
        <div style={{ maxHeight: 190, overflowY: "auto", display: "flex", flexDirection: "column", gap: 5, marginBottom: 16 }}>
          {catalog.length === 0 && <div style={{ color: C.muted, fontSize: 13, padding: "8px 0" }}>Sin resultados</div>}
          {catalog.map(p => {
            const inCart = items.find(i => i.id === p.id);
            const low = p.stock < p.minStock;
            return (
              <div key={p.id} onClick={() => toggle(p)} style={{ background: inCart ? C.accentDim : C.card, border: `1.5px solid ${inCart ? C.accent : C.border}`, borderRadius: 10, padding: "9px 12px", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{p.name}</div>
                  <div style={{ fontSize: 11, color: low ? C.danger : C.muted }}>Stock: {p.stock} {p.unit}{low ? " ⚠️" : ""}</div>
                </div>
                <div style={{ width: 26, height: 26, borderRadius: 8, background: inCart ? C.accent : C.border, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14, color: inCart ? "#000" : C.muted }}>
                  {inCart ? "✓" : "+"}
                </div>
              </div>
            );
          })}
        </div>

        <Label icon="✏️" text="Agregar manualmente" />
        <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
          <input placeholder="Insumo" value={manualName} onChange={e => setManualName(e.target.value)} onKeyDown={e => e.key === "Enter" && addManual()} style={{ flex: 2 }} />
          <select value={manualUnit} onChange={e => setManualUnit(e.target.value)} style={{ flex: 1 }}>
            {["kg","lt","unid","caja","bolsa","doc","gr","ml"].map(u => <option key={u}>{u}</option>)}
          </select>
          <button onClick={addManual} style={{ padding: "0 14px", background: C.accent, color: "#000", borderRadius: 10, border: "none", fontWeight: 700, fontSize: 18 }}>+</button>
        </div>

        {items.length > 0 && <>
          <Label icon="📋" text={`Pedido (${items.length} ítems)`} />
          <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
            {items.map(item => (
              <div key={item.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: "9px 12px", display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{item.name}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{item.unit}</div>
                </div>
                <QtyControl value={item.qty} onChange={v => setQty(item.id, v)} />
                <button onClick={() => setItems(prev => prev.filter(i => i.id !== item.id))} style={{ background: "none", border: "none", color: C.danger, fontSize: 17, padding: "0 2px" }}>✕</button>
              </div>
            ))}
          </div>
          <textarea placeholder="Nota para el proveedor (opcional)…" value={note} onChange={e => setNote(e.target.value)} rows={2} style={{ marginBottom: 14, resize: "none" }} />
          <button onClick={handleSend} style={{ width: "100%", background: sent ? C.success : "#25D366", border: "none", borderRadius: 12, padding: 14, color: "#fff", fontWeight: 700, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            {sent ? "✓ ¡Orden guardada!" : "📲 Enviar por WhatsApp"}
          </button>
        </>}
      </>}
      <Spacer />
    </div>
  );
}

// ─── STOCK ────────────────────────────────────────────────────────────────────
function TabStock({ suppliers, products, onUpdate }) {
  const [filter, setFilter] = useState("todos");
  const [editing, setEditing] = useState(null);
  const cats = ["todos", ...new Set(suppliers.map(s => s.category))];
  const critical = products.filter(p => p.stock < p.minStock).length;
  const filtered = products.filter(p => {
    if (filter === "todos") return true;
    return suppliers.find(s => s.id === p.supplierId)?.category === filter;
  });
  const saveEdit = (id, newStock) => { onUpdate(products.map(p => p.id === id ? { ...p, stock: Math.max(0, Number(newStock) || 0) } : p)); setEditing(null); };

  return (
    <div className="fu">
      {critical > 0 && (
        <div style={{ background: "#e84c6a15", border: `1px solid ${C.danger}`, borderRadius: 12, padding: "11px 14px", marginBottom: 14, display: "flex", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 20 }}>⚠️</span>
          <div>
            <div style={{ fontWeight: 700, color: C.danger, fontSize: 13 }}>{critical} insumo{critical > 1 ? "s" : ""} en stock crítico</div>
            <div style={{ fontSize: 11, color: C.muted }}>Generá una orden de compra</div>
          </div>
        </div>
      )}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 14, paddingBottom: 2 }}>
        {cats.map(c => (
          <button key={c} onClick={() => setFilter(c)} style={{ background: filter === c ? C.accent : C.card, border: `1px solid ${filter === c ? C.accent : C.border}`, borderRadius: 20, padding: "5px 13px", color: filter === c ? "#000" : C.muted, fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>
            {c.charAt(0).toUpperCase() + c.slice(1)}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {filtered.map(p => {
          const pct = Math.min(Math.round((p.stock / Math.max(p.minStock, 1)) * 100), 100);
          const barC = pct >= 80 ? C.success : pct >= 40 ? C.accent : C.danger;
          const sup = suppliers.find(s => s.id === p.supplierId);
          return (
            <div key={p.id} style={{ background: C.card, border: `1px solid ${p.stock < p.minStock ? C.danger + "50" : C.border}`, borderRadius: 12, padding: "12px 14px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{p.name}</div>
                  <div style={{ fontSize: 11, color: C.muted }}>{sup?.name || "—"}</div>
                </div>
                {editing === p.id
                  ? <EditStock p={p} onSave={saveEdit} onCancel={() => setEditing(null)} />
                  : <div style={{ textAlign: "right", cursor: "pointer" }} onClick={() => setEditing(p.id)}>
                      <div style={{ fontFamily: "'Space Mono',monospace", fontWeight: 700, color: p.stock < p.minStock ? C.danger : C.text, fontSize: 15 }}>{p.stock} <span style={{ fontSize: 11, color: C.muted }}>{p.unit}</span></div>
                      <div style={{ fontSize: 10, color: C.muted }}>mín {p.minStock} · ✏️</div>
                    </div>
                }
              </div>
              <div style={{ background: C.border, borderRadius: 4, height: 3 }}>
                <div style={{ width: `${pct}%`, height: "100%", background: barC, borderRadius: 4, transition: "width .4s" }} />
              </div>
            </div>
          );
        })}
      </div>
      <Spacer />
    </div>
  );
}

function EditStock({ p, onSave, onCancel }) {
  const [val, setVal] = useState(p.stock);
  return (
    <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
      <input type="number" value={val} onChange={e => setVal(e.target.value)} style={{ width: 64, padding: "4px 8px", textAlign: "center" }} autoFocus />
      <button onClick={() => onSave(p.id, val)} style={{ background: C.success, border: "none", borderRadius: 7, padding: "4px 8px", color: "#000", fontWeight: 700, fontSize: 12 }}>✓</button>
      <button onClick={onCancel} style={{ background: C.border, border: "none", borderRadius: 7, padding: "4px 8px", color: C.muted, fontWeight: 700, fontSize: 12 }}>✕</button>
    </div>
  );
}

// ─── HISTORIAL ────────────────────────────────────────────────────────────────
function TabHistorial({ history, suppliers, onUpdate }) {
  const [open, setOpen] = useState(null);
  const statusC = { entregada: C.success, pendiente: C.accent, cancelada: C.danger };

  const resend = (o) => {
    const sup = suppliers.find(s => s.id === o.supplierId);
    if (!sup) return;
    const lines = [`*Reorden — ${new Date().toLocaleDateString("es-AR")}*`, `Proveedor: ${o.supplierName}`, "─────────────────", ...o.items.map(i => `• ${i.name}: *${i.qty} ${i.unit}*`)];
    window.open(`https://wa.me/${sup.phone}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
  };

  return (
    <div className="fu">
      <Label icon="🕐" text={`${history.length} órdenes`} />
      {history.length === 0 && <div style={{ color: C.muted, fontSize: 13 }}>Aún no hay órdenes registradas.</div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {history.map(o => (
          <div key={o.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, overflow: "hidden" }}>
            <div onClick={() => setOpen(open === o.id ? null : o.id)} style={{ padding: "13px 14px", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                  <span style={{ fontFamily: "'Space Mono',monospace", fontWeight: 700, fontSize: 12, color: C.accent }}>{o.id}</span>
                  <span style={{ background: (statusC[o.status] || C.muted) + "25", color: statusC[o.status] || C.muted, fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 20 }}>{o.status}</span>
                </div>
                <div style={{ fontSize: 12, color: C.muted }}>{o.supplierName} · {new Date(o.date + "T12:00:00").toLocaleDateString("es-AR")}</div>
              </div>
              <span style={{ color: C.muted, fontSize: 18, display: "inline-block", transform: open === o.id ? "rotate(180deg)" : "none", transition: "transform .2s" }}>⌄</span>
            </div>
            {open === o.id && (
              <div style={{ borderTop: `1px solid ${C.border}`, padding: "12px 14px", display: "flex", flexDirection: "column", gap: 5 }}>
                {o.items.map((item, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                    <span style={{ color: C.muted }}>{item.name}</span>
                    <span style={{ fontWeight: 700, color: C.accent }}>{item.qty} {item.unit}</span>
                  </div>
                ))}
                <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                  <button onClick={() => resend(o)} style={{ flex: 1, background: "#25D36620", border: "1px solid #25D366", borderRadius: 9, padding: "8px", color: "#25D366", fontWeight: 700, fontSize: 12 }}>📲 Repetir</button>
                  {o.status !== "entregada" && (
                    <button onClick={() => onUpdate(history.map(h => h.id === o.id ? { ...h, status: "entregada" } : h))} style={{ flex: 1, background: C.success + "20", border: `1px solid ${C.success}`, borderRadius: 9, padding: "8px", color: C.success, fontWeight: 700, fontSize: 12 }}>✓ Entregada</button>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      <Spacer />
    </div>
  );
}

// ─── CONFIG ───────────────────────────────────────────────────────────────────
function TabConfig({ suppliers, products, onUpdateSuppliers, onUpdateProducts }) {
  const [section, setSection] = useState("proveedores");
  return (
    <div className="fu">
      <div style={{ display: "flex", gap: 6, marginBottom: 16 }}>
        {["proveedores", "productos"].map(s => (
          <button key={s} onClick={() => setSection(s)} style={{ flex: 1, background: section === s ? C.accent : C.card, border: `1px solid ${section === s ? C.accent : C.border}`, borderRadius: 10, padding: "9px", color: section === s ? "#000" : C.muted, fontWeight: 700, fontSize: 13 }}>
            {s === "proveedores" ? "🏪 Proveedores" : "📦 Productos"}
          </button>
        ))}
      </div>
      {section === "proveedores"
        ? <ConfigSuppliers suppliers={suppliers} onUpdate={onUpdateSuppliers} />
        : <ConfigProducts products={products} suppliers={suppliers} onUpdate={onUpdateProducts} />}
    </div>
  );
}

function ConfigSuppliers({ suppliers, onUpdate }) {
  const [form, setForm] = useState(null);
  const [editId, setEditId] = useState(null);
  const openNew = () => { setForm({ name: "", category: "", phone: "" }); setEditId(null); };
  const openEdit = (s) => { setForm({ name: s.name, category: s.category, phone: s.phone }); setEditId(s.id); };
  const save = () => {
    if (!form.name.trim()) return;
    if (editId) onUpdate(suppliers.map(s => s.id === editId ? { ...s, ...form } : s));
    else onUpdate([...suppliers, { id: Date.now(), ...form }]);
    setForm(null); setEditId(null);
  };
  const remove = (id) => { if (window.confirm("¿Eliminar proveedor?")) onUpdate(suppliers.filter(s => s.id !== id)); };

  return (
    <>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
        {suppliers.map(s => (
          <div key={s.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 11, padding: "11px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{s.name}</div>
              <div style={{ fontSize: 11, color: C.muted }}>{s.category} · 📱 {s.phone}</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <IconBtn onClick={() => openEdit(s)} label="✏️" />
              <IconBtn onClick={() => remove(s.id)} label="🗑️" danger />
            </div>
          </div>
        ))}
      </div>
      {form ? (
        <div style={{ background: C.card, border: `1px solid ${C.accent}`, borderRadius: 12, padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: C.accent, marginBottom: 4 }}>{editId ? "Editar proveedor" : "Nuevo proveedor"}</div>
          <input placeholder="Nombre *" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
          <input placeholder="Categoría (ej: Carnes)" value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))} />
          <input placeholder="Teléfono con código de país (ej: 549xxxxxxxxxx)" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <button onClick={save} style={{ flex: 1, background: C.accent, border: "none", borderRadius: 10, padding: 10, color: "#000", fontWeight: 700 }}>Guardar</button>
            <button onClick={() => setForm(null)} style={{ flex: 1, background: C.border, border: "none", borderRadius: 10, padding: 10, color: C.muted, fontWeight: 700 }}>Cancelar</button>
          </div>
        </div>
      ) : (
        <button onClick={openNew} style={{ width: "100%", background: C.accentDim, border: `1.5px dashed ${C.accent}`, borderRadius: 12, padding: 12, color: C.accent, fontWeight: 700, fontSize: 14 }}>+ Nuevo proveedor</button>
      )}
      <Spacer />
    </>
  );
}

function ConfigProducts({ products, suppliers, onUpdate }) {
  const [form, setForm] = useState(null);
  const [editId, setEditId] = useState(null);
  const [search, setSearch] = useState("");
  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  const openNew = () => { setForm({ name: "", unit: "kg", supplierId: suppliers[0]?.id || "", stock: 0, minStock: 10 }); setEditId(null); };
  const openEdit = (p) => { setForm({ name: p.name, unit: p.unit, supplierId: p.supplierId, stock: p.stock, minStock: p.minStock }); setEditId(p.id); };
  const save = () => {
    if (!form.name.trim()) return;
    const data = { ...form, supplierId: Number(form.supplierId), stock: Number(form.stock), minStock: Number(form.minStock) };
    if (editId) onUpdate(products.map(p => p.id === editId ? { ...p, ...data } : p));
    else onUpdate([...products, { id: Date.now(), ...data }]);
    setForm(null); setEditId(null);
  };
  const remove = (id) => { if (window.confirm("¿Eliminar producto?")) onUpdate(products.filter(p => p.id !== id)); };

  return (
    <>
      <input placeholder="Buscar producto…" value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 10 }} />
      <div style={{ maxHeight: 300, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6, marginBottom: 12 }}>
        {filtered.map(p => {
          const sup = suppliers.find(s => s.id === p.supplierId);
          return (
            <div key={p.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 10, padding: "10px 12px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13 }}>{p.name} <span style={{ color: C.muted, fontWeight: 400 }}>({p.unit})</span></div>
                <div style={{ fontSize: 11, color: C.muted }}>{sup?.name || "—"} · stock: {p.stock} · mín: {p.minStock}</div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <IconBtn onClick={() => openEdit(p)} label="✏️" />
                <IconBtn onClick={() => remove(p.id)} label="🗑️" danger />
              </div>
            </div>
          );
        })}
      </div>
      {form ? (
        <div style={{ background: C.card, border: `1px solid ${C.accent}`, borderRadius: 12, padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
          <div style={{ fontWeight: 700, fontSize: 13, color: C.accent, marginBottom: 4 }}>{editId ? "Editar producto" : "Nuevo producto"}</div>
          <input placeholder="Nombre *" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
          <div style={{ display: "flex", gap: 8 }}>
            <select value={form.unit} onChange={e => setForm(p => ({ ...p, unit: e.target.value }))} style={{ flex: 1 }}>
              {["kg","lt","unid","caja","bolsa","doc","gr","ml"].map(u => <option key={u}>{u}</option>)}
            </select>
            <select value={form.supplierId} onChange={e => setForm(p => ({ ...p, supplierId: e.target.value }))} style={{ flex: 2 }}>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <div style={{ flex: 1 }}><div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>Stock actual</div><input type="number" value={form.stock} onChange={e => setForm(p => ({ ...p, stock: e.target.value }))} /></div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}>Stock mínimo</div><input type="number" value={form.minStock} onChange={e => setForm(p => ({ ...p, minStock: e.target.value }))} /></div>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <button onClick={save} style={{ flex: 1, background: C.accent, border: "none", borderRadius: 10, padding: 10, color: "#000", fontWeight: 700 }}>Guardar</button>
            <button onClick={() => setForm(null)} style={{ flex: 1, background: C.border, border: "none", borderRadius: 10, padding: 10, color: C.muted, fontWeight: 700 }}>Cancelar</button>
          </div>
        </div>
      ) : (
        <button onClick={openNew} style={{ width: "100%", background: C.accentDim, border: `1.5px dashed ${C.accent}`, borderRadius: 12, padding: 12, color: C.accent, fontWeight: 700, fontSize: 14 }}>+ Nuevo producto</button>
      )}
      <Spacer />
    </>
  );
}

// ─── ASISTENTE IA ─────────────────────────────────────────────────────────────
function TabIA({ suppliers, products }) {
  const [msgs, setMsgs] = useState([
    { role: "assistant", text: "¡Hola! Soy tu asistente de compras 🤖\n\nPuedo ayudarte a:\n• Sugerir qué pedir según el stock\n• Armar pedidos por proveedor\n• Calcular cantidades\n\n¿Qué necesitás?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, loading]);

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg || loading) return;
    setInput("");
    setMsgs(prev => [...prev, { role: "user", text: msg }]);
    setLoading(true);

    const stockInfo = products.map(p => {
      const sup = suppliers.find(s => s.id === p.supplierId);
      const status = p.stock < p.minStock ? "CRÍTICO" : p.stock < p.minStock * 1.5 ? "bajo" : "ok";
      return `- ${p.name} (${p.unit}): stock ${p.stock}/${p.minStock} [${status}] — ${sup?.name}`;
    }).join("\n");

    const system = `Sos un asistente de compras para un restaurante argentino. Ayudás a gestionar órdenes de materia prima.\n\nSTOCK ACTUAL:\n${stockInfo}\n\nPROVEEDORES:\n${suppliers.map(s => `- ${s.name} (${s.category})`).join("\n")}\n\nRespondé en español rioplatense, de forma concisa y práctica. Si hay productos críticos priorizalos. Al sugerir cantidades, calculá para reponer al doble del stock mínimo.`;

    try {
      const history = msgs.map(m => ({ role: m.role, content: m.text }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, system, messages: [...history, { role: "user", content: msg }] }),
      });
      const data = await res.json();
      const reply = data.content?.map(c => c.text || "").join("") || "No pude responder.";
      setMsgs(prev => [...prev, { role: "assistant", text: reply }]);
    } catch {
      setMsgs(prev => [...prev, { role: "assistant", text: "Error de conexión. Intentá de nuevo." }]);
    } finally {
      setLoading(false);
    }
  };

  const quick = ["¿Qué me falta pedir urgente?", "Armá un pedido a Frigorífico Central", "¿Qué tengo en stock crítico?"];

  return (
    <div className="fu" style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 155px)" }}>
      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8, paddingBottom: 10 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{ maxWidth: "88%", background: m.role === "user" ? C.accent : C.card, color: m.role === "user" ? "#000" : C.text, border: m.role === "assistant" ? `1px solid ${C.border}` : "none", borderRadius: m.role === "user" ? "14px 14px 3px 14px" : "14px 14px 14px 3px", padding: "10px 13px", fontSize: 13, lineHeight: 1.55, whiteSpace: "pre-wrap" }}>{m.text}</div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex" }}>
            <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: "14px 14px 14px 3px", padding: "10px 16px", color: C.muted, animation: "pulse 1.2s infinite", fontSize: 16 }}>● ● ●</div>
          </div>
        )}
        <div ref={endRef} />
      </div>
      {msgs.length === 1 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 5, marginBottom: 8 }}>
          {quick.map((q, i) => (
            <button key={i} onClick={() => send(q)} style={{ background: C.accentDim, border: `1px solid ${C.accentLight}`, borderRadius: 9, padding: "8px 12px", color: C.accent, fontSize: 12, fontWeight: 600, textAlign: "left" }}>{q}</button>
          ))}
        </div>
      )}
      <div style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && !e.shiftKey && send()} placeholder="Preguntá sobre tus compras…" />
        <button onClick={() => send()} disabled={loading} style={{ background: C.accent, border: "none", borderRadius: 11, padding: "0 16px", color: "#000", fontWeight: 700, fontSize: 18, opacity: loading ? .5 : 1 }}>↑</button>
      </div>
    </div>
  );
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function Label({ icon, text }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
      <span style={{ fontSize: 14 }}>{icon}</span>
      <span style={{ fontSize: 11, fontWeight: 700, color: C.muted, textTransform: "uppercase", letterSpacing: 1 }}>{text}</span>
    </div>
  );
}
function QtyControl({ value, onChange }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
      <button onClick={() => onChange(value - 1)} style={{ background: C.border, border: "none", borderRadius: 7, width: 28, height: 28, color: C.text, fontSize: 17, fontWeight: 700 }}>−</button>
      <input type="number" value={value} onChange={e => onChange(e.target.value)} style={{ width: 46, textAlign: "center", padding: "4px 2px", fontSize: 13 }} />
      <button onClick={() => onChange(value + 1)} style={{ background: C.border, border: "none", borderRadius: 7, width: 28, height: 28, color: C.text, fontSize: 17, fontWeight: 700 }}>+</button>
    </div>
  );
}
function IconBtn({ onClick, label, danger }) {
  return <button onClick={onClick} style={{ background: danger ? C.danger + "20" : C.accentDim, border: `1px solid ${danger ? C.danger + "50" : C.accentLight}`, borderRadius: 8, padding: "5px 9px", fontSize: 14 }}>{label}</button>;
}
function Spacer() { return <div style={{ height: 24 }} />; }
